# Note that this script does _not_ use a shebang as it is designed to be run to
# show the difference between sourcing shell scripts and executing shell scripts.
EDITOR=nano
echo "Editor changed to: $EDITOR"
