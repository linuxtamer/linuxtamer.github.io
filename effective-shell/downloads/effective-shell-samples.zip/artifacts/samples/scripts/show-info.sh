#!/usr/bin/env sh
echo "Current Directory: $PWD"
